package com.example.classcard;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText e_startnum = findViewById(R.id.edit_StartNum);
        EditText e_endnum = findViewById(R.id.edit_EndNum);
        Button b_start = findViewById(R.id.button_start);
        Button b_mix = findViewById(R.id.button_mix);
        Button b_show = findViewById(R.id.button_show);
        Button b_prev = findViewById(R.id.button_prev);
        TextView t_index = findViewById(R.id.text_index);
        Button b_next = findViewById(R.id.button_next);
        TextView t_english = findViewById(R.id.text_english);
        TextView t_hangul = findViewById(R.id.text_hangul);
        TextView t_day = findViewById(R.id.text_day);
        CheckBox c_done = findViewById(R.id.check_done);
        CheckBox c_keep = findViewById(R.id.check_keep);

        b_start.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (TextUtils.isEmpty(e_startnum.getText().toString())) {
                    Toast.makeText(getBaseContext(), "start empty", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(e_endnum.getText().toString())) {
                    Toast.makeText(getBaseContext(), "end empty", Toast.LENGTH_SHORT).show();
                    return;
                }

                int nstart, nend;
                //System.out.println(e_startnum.getText().toString());

                nstart = Integer.parseInt(e_startnum.getText().toString());
                if (nstart < 0) {
                    e_startnum.setText("0");
                    nstart = 0;
                }
                else if (nstart > 60) {
                    e_startnum.setText("60");
                    nstart = 60;
                }
                nend = Integer.parseInt(e_endnum.getText().toString());
                if (nend < 0) {
                    e_endnum.setText("0");
                    nend = 0;
                }
                else if (nend > 60) {
                    e_endnum.setText("60");
                    nend = 60;
                }

                if (nstart > nend) {
                    Toast.makeText(getBaseContext(), "start > end", Toast.LENGTH_SHORT).show();
                    return;
                }

                c_done.setChecked(false);
                c_keep.setChecked(false);
                g_index = 0;
                readCardData(nstart, nend);
                g_isstart = 1;

                int s_index = g_index + 1;
                t_index.setText(s_index + "/" + carddata.size());

                String[] tokens = carddata.get(g_index).split("\\|");
                t_english.setText(tokens[1]);
                t_hangul.setText("");
                t_day.setText("");
                //t_english.setText(e_startnum.getText());
            }
        });

        b_mix.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (carddata.size() > 1) {
                    Collections.shuffle(carddata);
                    g_index = 0;
                    String[] tokens = carddata.get(g_index).split("\\|");
                    t_english.setText(tokens[1]);
                    t_hangul.setText("");
                    t_day.setText("");
                    int s_index = g_index + 1;
                    t_index.setText(s_index + "/" + carddata.size());
                }
            }
        });

        b_show.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (g_isstart == 0) {
                    Toast.makeText(getBaseContext(), "not start", Toast.LENGTH_SHORT).show();
                    return;
                }

                String[] tokens = carddata.get(g_index).split("\\|");
                t_hangul.setText(tokens[2]);
                t_day.setText("day " + tokens[0]);
            }
        });

        b_prev.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (g_isstart == 0) {
                    Toast.makeText(getBaseContext(), "not start", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (g_index == 0) {
                    //Toast.makeText(getBaseContext(), "is first", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (c_done.isChecked()) {
                    if (carddata.size() == 1) {
                        Toast.makeText(getBaseContext(), "finish", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    carddata.remove(g_index);
                    g_index -= 1;
                    if (g_index < 0)
                        g_index = 0;
                    //c_done.setChecked(false);
                }
                else {
                    g_index -= 1;
                }
                c_done.setChecked(c_keep.isChecked());

                if (g_index < 0)
                    g_index = 0;
                String[] tokens = carddata.get(g_index).split("\\|");
                t_english.setText(tokens[1]);
                t_hangul.setText("");
                t_day.setText("");

                int s_index = g_index + 1;
                t_index.setText(s_index + "/" + carddata.size());
            }
        });

        b_next.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (g_isstart == 0) {
                    Toast.makeText(getBaseContext(), "not start", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (g_index + 1 == carddata.size()) {
                    //Toast.makeText(getBaseContext(), "is last", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (c_done.isChecked()) {
                    if (carddata.size() == 1) {
                        Toast.makeText(getBaseContext(), "finish", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    carddata.remove(g_index);
                    //c_done.setChecked(false);
                }
                else {
                    g_index += 1;
                }
                c_done.setChecked(c_keep.isChecked());

                if (g_index >= carddata.size() - 1)
                    g_index = carddata.size() - 1;

                //System.out.println(carddata.size() + "   " + g_index);

                String[] tokens = carddata.get(g_index).split("\\|");
                t_english.setText(tokens[1]);
                t_hangul.setText("");
                t_day.setText("");

                int s_index = g_index + 1;
                t_index.setText(s_index + "/" + carddata.size());
            }
        });

        c_keep.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (c_keep.isChecked() == true) {
                    c_done.setChecked(true);
                }
                else {
                    c_done.setChecked(false);
                }
            }
        });
    }
    private List<String> carddata = new ArrayList<>();
    public int g_index=0;
    public int g_isstart=0;

    private void readCardData(int nstart, int nend) {
        InputStream is = getResources().openRawResource(R.raw.data);
        BufferedReader reader = new BufferedReader(
                new InputStreamReader(is, Charset.forName("UTF-8"))
        );

        carddata.clear();
        String line = "";
        try {
            while ((line = reader.readLine()) != null) {
                String[] tokens = line.split("\\|");
                if (Integer.parseInt(tokens[0]) < nstart)
                    continue;
                if (Integer.parseInt(tokens[0]) > nend)
                    break;

                carddata.add(line);
            }
            Collections.shuffle(carddata);
            reader.close();
        } catch (IOException e) {
            Log.wtf("MyActivity", "Error reading data " + line, e);
            e.printStackTrace();
        }
    }
}